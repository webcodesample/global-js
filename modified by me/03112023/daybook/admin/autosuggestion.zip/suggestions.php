<?php error_reporting(0);
	
	$con = mysql_connect('localhost', 'root','');
	$db	 = mysql_select_db('fashiondears');
	$query 	= $_REQUEST['term'];
	$sql 	= "select name from `fd_sub_category` where name like '%$query%'";
	$query 	= mysql_query($sql);
	while($row = mysql_fetch_assoc($query)){
		$val[] = $row['name'];
	}
	echo json_encode($val);

?>